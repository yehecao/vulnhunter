#!/usr/bin/env bash
set -euo pipefail
sudo install -m 0755 dist/vulnhunter /usr/local/bin/vulnhunter
sudo install -d -m 0755 /opt/vulnhunter/plugins /etc/vulnhunter
sudo cp -a plugins/. /opt/vulnhunter/plugins/
sudo install -m 0644 configs/vulnhunter.env.example /etc/vulnhunter/vulnhunter.env.example
sudo install -m 0644 deployments/systemd/vulnhunter.service /etc/systemd/system/vulnhunter.service
sudo systemctl daemon-reload
echo "Binary and reviewed plugins installed. Copy the example env file to /etc/vulnhunter/vulnhunter.env, set VH_PLUGIN_DIR=/opt/vulnhunter/plugins, DATABASE_URL and VH_ALLOWED_CIDRS, then apply both SQL migrations before enabling the service."
