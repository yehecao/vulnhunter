#!/usr/bin/env bash
set -euo pipefail
mkdir -p dist
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -trimpath -ldflags='-s -w' -o dist/vulnhunter ./cmd/vulnhunter
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -trimpath -ldflags='-s -w' -o dist/vulnhunter-import-nvd ./cmd/vulnhunter-import-nvd
echo "Built dist/vulnhunter and dist/vulnhunter-import-nvd"
