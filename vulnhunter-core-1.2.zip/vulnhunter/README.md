# VulnHunter Core 1.1

A first-stage, authorized-network inventory and vulnerability-scanner foundation.

## Included

- Go HTTP API and asynchronous scan worker
- Explicit CIDR allowlist enforcement
- TCP connect scanning with bounded concurrency and timeouts
- Lightweight HTTP/SSH service fingerprinting
- PostgreSQL persistence for tasks, assets, services, and findings
- Python subprocess plugin protocol example
- Native Linux build/install scripts
- Docker Compose for local PostgreSQL development only

## Security scope

Only scan systems you own or are explicitly authorized to assess. Configure `VH_ALLOWED_CIDRS`
before starting the manager. Every submitted target must be wholly contained in one of those
CIDRs. The API binds to loopback by default. Do not expose it directly to an untrusted network.

This MVP performs non-exploitative TCP connection checks and basic protocol identification.
It does not perform exploit validation, password guessing, stealth scanning, or destructive tests.

## Requirements

- Go 1.23+
- PostgreSQL 15+
- Python 3.10+ (only for Python plugins)

## Quick start

```bash
# 1. Start a local PostgreSQL for development
docker compose up -d postgres

# 2. Create schema
export DATABASE_URL='postgres://vulnhunter:vulnhunter-dev-only@127.0.0.1:5432/vulnhunter?sslmode=disable'
psql "$DATABASE_URL" -f migrations/001_init.sql
psql "$DATABASE_URL" -f migrations/002_plugin_findings.sql
psql "$DATABASE_URL" -f migrations/003_cve_intelligence.sql

# 3. Configure authorized scope (example lab network only)
export VH_ALLOWED_CIDRS='192.168.56.0/24'
export VH_LISTEN_ADDR='127.0.0.1:8080'
export VH_PORTS='22,23,80,443,445,3306,5432,6379,8080'
export VH_PLUGIN_DIR='./plugins'
export VH_PYTHON_PATH='python3'
export VH_MAX_HOSTS='4096'

# 4. Run
go mod tidy
go run ./cmd/vulnhunter

# 5. Submit a scan (target must be inside VH_ALLOWED_CIDRS)
curl -sS -X POST http://127.0.0.1:8080/api/v1/scans \
  -H 'Content-Type: application/json' \
  -d '{"name":"lab inventory","targets":["192.168.56.10"],"ports":[22,80,443]}'

# 6. Query tasks and assets
curl http://127.0.0.1:8080/api/v1/scans
curl http://127.0.0.1:8080/api/v1/assets
curl http://127.0.0.1:8080/api/v1/findings
```

## API

- `GET /healthz`
- `POST /api/v1/scans`
- `GET /api/v1/scans`
- `GET /api/v1/scans/{id}`
- `POST /api/v1/scans/{id}/cancel`
- `GET /api/v1/assets`
- `GET /api/v1/findings`
- `GET /api/v1/vulnerabilities`

Example request:

```json
{
  "name": "lab inventory",
  "targets": ["192.168.56.0/28"],
  "ports": [22, 80, 443, 8080]
}
```

The manager validates targets against `VH_ALLOWED_CIDRS`, caps expansion with `VH_MAX_HOSTS`,
and limits concurrent TCP dials with `VH_CONCURRENCY`. The current MVP runs jobs in-process;
a later phase should move execution to separately supervised scanner agents and a durable queue.

## Python plugin protocol

`plugins/telnet_policy/manifest.json` and `plugin.py` demonstrate the subprocess
contract. The manager passes one JSON object on stdin and expects one JSON object on stdout.
The sample plugin only evaluates supplied service metadata; it does not make network requests.
Use `GET /api/v1/plugins` to inspect enabled plugins. Restart the manager after plugin changes.

## Native Linux build

```bash
./scripts/build-linux.sh
sudo install -m 0755 dist/vulnhunter /usr/local/bin/vulnhunter
```

Example systemd unit: `deployments/systemd/vulnhunter.service`.

## Production hardening before deployment

- Put the API behind TLS/mTLS or a trusted reverse proxy; add authentication and RBAC.
- Run as an unprivileged dedicated OS account.
- Store DB credentials in a secret manager or root-readable environment file.
- Add signed plugin packages, process/container sandboxing, and strict plugin egress controls.
- Add durable queueing, worker leases, task recovery, and scan audit trails.
- Load-test only in an isolated lab and tune rate limits for the network owner.

## VulnHunter 1.1 — Python plugin engine

VulnHunter 1.1 adds local plugin discovery and automatic execution after service fingerprinting.
Plugins are trusted local code: only install scripts reviewed by your security team. Do not accept plugin uploads from scan API clients.

### Plugin layout

Each plugin lives in its own directory under `VH_PLUGIN_DIR` and contains a strict JSON manifest plus a Python entrypoint:

```text
plugins/
  telnet_policy/
    manifest.json
    plugin.py
```

Example manifest:

```json
{
  "id": "vh.telnet-policy",
  "name": "Telnet Exposure Policy",
  "version": "1.0.0",
  "runtime": "python3",
  "entrypoint": "plugin.py",
  "timeout_ms": 2000,
  "enabled": true
}
```

Manifest rules: plugin IDs must be unique-style identifiers (3–128 characters); runtime must be `python3`; entrypoints must be `.py` files inside the plugin directory; timeout must be 100–30000 ms. An optional `sha256` field pins the entrypoint file digest. Set `enabled` to `false` to skip a plugin.

### Plugin stdin/stdout protocol

The manager starts the configured interpreter as a separate process, sends one JSON object to stdin, and expects one JSON object on stdout. Do not print logs to stdout; use stderr for diagnostics.

Request:

```json
{
  "plugin_id": "vh.telnet-policy",
  "target": {
    "ip": "192.168.56.10",
    "port": 23,
    "protocol": "tcp",
    "service": "telnet",
    "product": "",
    "version": "",
    "banner": "",
    "confidence": 0.35
  }
}
```

Response:

```json
{
  "status": "completed",
  "findings": [
    {
      "plugin_id": "vh.telnet-policy",
      "title": "Telnet service exposed",
      "severity": "medium",
      "confidence": 0.98,
      "evidence": {"port": 23},
      "remediation": "Disable Telnet and use SSH."
    }
  ]
}
```

Allowed severities are `info`, `low`, `medium`, `high`, and `critical`. Confidence must be between 0 and 1. A plugin may return an empty findings array. Results are stored in `scan_findings`; remediation is stored in its dedicated column and returned by `GET /api/v1/findings`.

### Configuration and API

```bash
VH_PLUGIN_DIR=./plugins
VH_PYTHON_PATH=python3
```

New endpoint:

- `GET /api/v1/plugins` — lists enabled plugin metadata.

Apply the new migration after the original schema:

```bash
psql "$DATABASE_URL" -f migrations/002_plugin_findings.sql
```

Then restart VulnHunter. Plugin discovery happens at process startup, so restart after adding, changing, or disabling a plugin.

### Important security boundary

The current runner provides process separation and per-plugin timeouts, but it is **not a complete sandbox**. Python plugins run with the VulnHunter service account's OS permissions and may inherit its network access. In production, run the scanner under a dedicated unprivileged account and add OS-level isolation (for example systemd hardening, filesystem restrictions, and egress firewall rules). Keep the API bound to localhost until authentication and authorization are implemented. Only scan explicitly authorized CIDRs.

## VulnHunter 1.2 — CPE/CVE intelligence matching

VulnHunter 1.2 adds an offline-first CVE intelligence importer and conservative
version-range matching. It currently fingerprints explicit versions for nginx,
Apache HTTP Server, and OpenSSH when the remote service discloses them. Unknown
products or missing versions are not matched. The matcher stores results as
`potential` with `verification=not_verified`; a CPE/version match is a candidate,
not proof that the host is exploitable or unpatched.

### Apply migration

```bash
psql "$DATABASE_URL" -f migrations/003_cve_intelligence.sql
```

### Import an NVD CVE API 2.0 JSON response

Download an NVD JSON response through your organization's approved network path,
then import it locally:

```bash
go build -o dist/vulnhunter-import-nvd ./cmd/vulnhunter-import-nvd
DATABASE_URL="$DATABASE_URL" ./dist/vulnhunter-import-nvd -file ./nvdcve-2.0.json
```

The importer upserts CVE metadata and vulnerable CPE version-range criteria. It can
be rerun after downloading an updated feed. For production, schedule incremental
NVD modified-date feeds and record feed timestamps/checksums in your operations
pipeline; this MVP does not yet perform automatic network synchronization.

### New API

- `GET /api/v1/vulnerabilities` — latest imported CVE metadata (up to 500 rows)
- `GET /api/v1/findings` — includes `cve_id` and `match_status` for CVE candidates

When a scan identifies a supported product and version, the manager loads its CPE
rules and writes potential CVE findings. The current version comparator handles
common numeric/alphanumeric version tokens; vendor-specific suffixes, backports,
package revisions, distro patches, and complex CPE logical expressions can require
additional product-specific logic. Always verify against vendor advisories and
installed package metadata before treating a candidate as confirmed.
