package model

import "time"

type ScanRequest struct {
	Name    string   `json:"name"`
	Targets []string `json:"targets"`
	Ports   []int    `json:"ports"`
}

type Task struct {
	ID        string     `json:"id"`
	Name      string     `json:"name"`
	Status    string     `json:"status"`
	CreatedAt time.Time  `json:"created_at"`
	StartedAt *time.Time `json:"started_at,omitempty"`
	EndedAt   *time.Time `json:"ended_at,omitempty"`
	Error     string     `json:"error,omitempty"`
}

type Asset struct {
	ID        string    `json:"id"`
	IP        string    `json:"ip"`
	Hostname  string    `json:"hostname,omitempty"`
	FirstSeen time.Time `json:"first_seen"`
	LastSeen  time.Time `json:"last_seen"`
}

type Service struct {
	AssetID    string  `json:"asset_id"`
	IP         string  `json:"ip"`
	Port       int     `json:"port"`
	Protocol   string  `json:"protocol"`
	Service    string  `json:"service"`
	Product    string  `json:"product,omitempty"`
	Version    string  `json:"version,omitempty"`
	Banner     string  `json:"banner,omitempty"`
	Confidence float64 `json:"confidence"`
}

type Finding struct {
	ID          string         `json:"id"`
	TaskID      string         `json:"task_id"`
	AssetID     string         `json:"asset_id"`
	PluginID    string         `json:"plugin_id"`
	CVEID       string         `json:"cve_id,omitempty"`
	MatchStatus string         `json:"match_status,omitempty"`
	Title       string         `json:"title"`
	Severity    string         `json:"severity"`
	Remediation string         `json:"remediation,omitempty"`
	Confidence  float64        `json:"confidence"`
	Evidence    map[string]any `json:"evidence"`
	CreatedAt   time.Time      `json:"created_at"`
}

type Vulnerability struct {
	CVEID       string     `json:"cve_id"`
	Title       string     `json:"title"`
	Description string     `json:"description,omitempty"`
	CVSSScore   float64    `json:"cvss_score"`
	Severity    string     `json:"severity"`
	PublishedAt *time.Time `json:"published_at,omitempty"`
	ModifiedAt  *time.Time `json:"modified_at,omitempty"`
}
