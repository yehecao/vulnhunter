package store

import (
	"context"
	"crypto/rand"
	"encoding/json"
	"fmt"
	"time"

	"github.com/example/vulnhunter/internal/model"
	"github.com/example/vulnhunter/internal/vuln"
	"github.com/jackc/pgx/v5/pgxpool"
)

type Store struct{ Pool *pgxpool.Pool }

func Open(ctx context.Context, dsn string) (*Store, error) {
	p, err := pgxpool.New(ctx, dsn)
	if err != nil {
		return nil, err
	}
	if err := p.Ping(ctx); err != nil {
		p.Close()
		return nil, err
	}
	return &Store{Pool: p}, nil
}
func (s *Store) Close() { s.Pool.Close() }

func (s *Store) CreateTask(ctx context.Context, name string, targets []string, ports []int) (model.Task, error) {
	id, err := newUUID()
	if err != nil {
		return model.Task{}, err
	}
	t := model.Task{ID: id, Name: name, Status: "queued", CreatedAt: time.Now().UTC()}
	_, err = s.Pool.Exec(ctx, `INSERT INTO scan_tasks(id,name,status,target_scope,ports,created_at)
		VALUES($1,$2,$3,$4,$5,$6)`, id, name, t.Status, targets, ports, t.CreatedAt)
	return t, err
}
func (s *Store) SetTaskStatus(ctx context.Context, id, status, errText string) error {
	_, err := s.Pool.Exec(ctx, `UPDATE scan_tasks SET status=$2,error_text=NULLIF($3,''),
		started_at=CASE WHEN $2='running' THEN now() ELSE started_at END,
		finished_at=CASE WHEN $2 IN ('completed','failed','cancelled') THEN now() ELSE finished_at END
		WHERE id=$1`, id, status, errText)
	return err
}
func (s *Store) UpsertAsset(ctx context.Context, ip string) (string, error) {
	var id string
	err := s.Pool.QueryRow(ctx, `INSERT INTO assets(ip_address,first_seen,last_seen)
		VALUES($1::inet,now(),now())
		ON CONFLICT(ip_address) DO UPDATE SET last_seen=now()
		RETURNING id::text`, ip).Scan(&id)
	return id, err
}
func (s *Store) UpsertService(ctx context.Context, v model.Service) error {
	_, err := s.Pool.Exec(ctx, `INSERT INTO asset_services(asset_id,port,protocol,service_name,product,version,banner,confidence,last_seen)
		VALUES($1::uuid,$2,$3,$4,$5,$6,$7,$8,now())
		ON CONFLICT(asset_id,port,protocol) DO UPDATE SET service_name=EXCLUDED.service_name,
		product=EXCLUDED.product,version=EXCLUDED.version,banner=EXCLUDED.banner,
		confidence=EXCLUDED.confidence,last_seen=now()`,
		v.AssetID, v.Port, v.Protocol, v.Service, v.Product, v.Version, v.Banner, v.Confidence)
	return err
}
func (s *Store) CreateFinding(ctx context.Context, taskID, assetID, pluginID, title, severity, remediation string, confidence float64, evidence map[string]any) error {
	b, _ := json.Marshal(evidence)
	_, err := s.Pool.Exec(ctx, `INSERT INTO scan_findings(task_id,asset_id,plugin_id,title,severity,confidence,evidence,remediation,created_at)
		VALUES($1::uuid,$2::uuid,$3,$4,$5,$6,$7::jsonb,$8,now())`,
		taskID, assetID, pluginID, title, severity, confidence, string(b), remediation)
	return err
}
func (s *Store) ListTasks(ctx context.Context) ([]model.Task, error) {
	rows, err := s.Pool.Query(ctx, `SELECT id::text,name,status,created_at,started_at,finished_at,COALESCE(error_text,'') FROM scan_tasks ORDER BY created_at DESC LIMIT 100`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []model.Task{}
	for rows.Next() {
		var t model.Task
		if err := rows.Scan(&t.ID, &t.Name, &t.Status, &t.CreatedAt, &t.StartedAt, &t.EndedAt, &t.Error); err != nil {
			return nil, err
		}
		out = append(out, t)
	}
	return out, rows.Err()
}
func (s *Store) GetTask(ctx context.Context, id string) (model.Task, error) {
	var t model.Task
	err := s.Pool.QueryRow(ctx, `SELECT id::text,name,status,created_at,started_at,finished_at,COALESCE(error_text,'') FROM scan_tasks WHERE id=$1::uuid`, id).
		Scan(&t.ID, &t.Name, &t.Status, &t.CreatedAt, &t.StartedAt, &t.EndedAt, &t.Error)
	return t, err
}
func (s *Store) ListAssets(ctx context.Context) ([]model.Asset, error) {
	rows, err := s.Pool.Query(ctx, `SELECT id::text,host(ip_address),COALESCE(hostname,''),first_seen,last_seen FROM assets ORDER BY last_seen DESC LIMIT 500`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []model.Asset{}
	for rows.Next() {
		var a model.Asset
		if err := rows.Scan(&a.ID, &a.IP, &a.Hostname, &a.FirstSeen, &a.LastSeen); err != nil {
			return nil, err
		}
		out = append(out, a)
	}
	return out, rows.Err()
}
func (s *Store) ListFindings(ctx context.Context) ([]model.Finding, error) {
	rows, err := s.Pool.Query(ctx, `SELECT id::text,task_id::text,asset_id::text,plugin_id,title,severity,confidence,evidence,remediation,created_at,COALESCE(cve_id,''),match_status FROM scan_findings ORDER BY created_at DESC LIMIT 500`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []model.Finding{}
	for rows.Next() {
		var f model.Finding
		var raw []byte
		if err := rows.Scan(&f.ID, &f.TaskID, &f.AssetID, &f.PluginID, &f.Title, &f.Severity, &f.Confidence, &raw, &f.Remediation, &f.CreatedAt, &f.CVEID, &f.MatchStatus); err != nil {
			return nil, err
		}
		_ = json.Unmarshal(raw, &f.Evidence)
		out = append(out, f)
	}
	return out, rows.Err()
}

func newUUID() (string, error) {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	b[6] = (b[6] & 0x0f) | 0x40
	b[8] = (b[8] & 0x3f) | 0x80
	return fmt.Sprintf("%x-%x-%x-%x-%x", b[0:4], b[4:6], b[6:8], b[8:10], b[10:16]), nil
}

func (s *Store) ImportVulnerability(ctx context.Context, v vuln.CVERecord) error {
	var published, modified any
	if !v.Published.IsZero() {
		published = v.Published
	}
	if !v.Modified.IsZero() {
		modified = v.Modified
	}
	tx, err := s.Pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)
	_, err = tx.Exec(ctx, `INSERT INTO vulnerabilities(cve_id,title,description,cvss_score,cvss_vector,severity,published_at,modified_at)
		VALUES($1,$2,$3,$4,$5,$6,$7,$8)
		ON CONFLICT(cve_id) DO UPDATE SET title=EXCLUDED.title,description=EXCLUDED.description,cvss_score=EXCLUDED.cvss_score,
		cvss_vector=EXCLUDED.cvss_vector,severity=EXCLUDED.severity,published_at=EXCLUDED.published_at,modified_at=EXCLUDED.modified_at`,
		v.ID, v.Title, v.Description, v.Score, v.Vector, v.Severity, published, modified)
	if err != nil {
		return err
	}
	if _, err = tx.Exec(ctx, `DELETE FROM cve_cpe_matches WHERE cve_id=$1`, v.ID); err != nil {
		return err
	}
	for _, m := range v.Matches {
		_, err = tx.Exec(ctx, `INSERT INTO cve_cpe_matches(cve_id,criteria,vendor,product,version_start_including,version_start_excluding,version_end_including,version_end_excluding)
			VALUES($1,$2,$3,$4,NULLIF($5,''),NULLIF($6,''),NULLIF($7,''),NULLIF($8,''))`,
			v.ID, m.Criteria, m.Vendor, m.Product, m.VersionStartIncluding, m.VersionStartExcluding, m.VersionEndIncluding, m.VersionEndExcluding)
		if err != nil {
			return err
		}
	}
	return tx.Commit(ctx)
}

func (s *Store) CVEMatches(ctx context.Context, vendor, product string) ([]vuln.CPEMatch, error) {
	rows, err := s.Pool.Query(ctx, `SELECT m.cve_id,m.criteria,m.vendor,m.product,COALESCE(m.version_start_including,''),COALESCE(m.version_start_excluding,''),COALESCE(m.version_end_including,''),COALESCE(m.version_end_excluding,''),COALESCE(v.severity,'unknown'),COALESCE(v.cvss_score,0)
		FROM cve_cpe_matches m JOIN vulnerabilities v ON v.cve_id=m.cve_id WHERE m.vendor=$1 AND m.product=$2 AND m.vulnerable=true`, vendor, product)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []vuln.CPEMatch{}
	for rows.Next() {
		var m vuln.CPEMatch
		if err := rows.Scan(&m.CVEID, &m.Criteria, &m.Vendor, &m.Product, &m.VersionStartIncluding, &m.VersionStartExcluding, &m.VersionEndIncluding, &m.VersionEndExcluding, &m.Severity, &m.Score); err != nil {
			return nil, err
		}
		out = append(out, m)
	}
	return out, rows.Err()
}

func (s *Store) CreateCVEFinding(ctx context.Context, taskID, assetID string, candidate vuln.Candidate, severity string, score float64) error {
	evidence := map[string]any{"product": candidate.Product, "installed_version": candidate.InstalledVersion, "cpe_criteria": candidate.Criteria, "match_reason": candidate.Reason, "cvss_score": score, "verification": "not_verified"}
	b, _ := json.Marshal(evidence)
	_, err := s.Pool.Exec(ctx, `INSERT INTO scan_findings(task_id,asset_id,plugin_id,cve_id,match_status,title,severity,confidence,evidence,remediation,created_at)
		VALUES($1::uuid,$2::uuid,'vh.cve-matcher',$3,'potential',$4,$5,0.65,$6::jsonb,'请核实厂商公告、补丁级别及实际配置；按厂商安全公告升级或缓解。',now()) ON CONFLICT DO NOTHING`,
		taskID, assetID, candidate.CVEID, candidate.CVEID+" - version range match", severity, string(b))
	return err
}

func (s *Store) ListVulnerabilities(ctx context.Context) ([]model.Vulnerability, error) {
	rows, err := s.Pool.Query(ctx, `SELECT cve_id,title,COALESCE(description,''),COALESCE(cvss_score,0),COALESCE(severity,'unknown'),published_at,modified_at FROM vulnerabilities ORDER BY modified_at DESC NULLS LAST LIMIT 500`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []model.Vulnerability{}
	for rows.Next() {
		var v model.Vulnerability
		if err := rows.Scan(&v.CVEID, &v.Title, &v.Description, &v.CVSSScore, &v.Severity, &v.PublishedAt, &v.ModifiedAt); err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, rows.Err()
}
