package config

import (
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"
	"time"
)

type Config struct {
	DatabaseURL string
	ListenAddr  string
	Allowed     []*net.IPNet
	Ports       []int
	MaxHosts    int
	Concurrency int
	Timeout     time.Duration
	PluginDir   string
	PythonPath  string
}

func Load() (Config, error) {
	c := Config{
		DatabaseURL: os.Getenv("DATABASE_URL"),
		ListenAddr:  env("VH_LISTEN_ADDR", "127.0.0.1:8080"),
		MaxHosts:    envInt("VH_MAX_HOSTS", 4096),
		Concurrency: envInt("VH_CONCURRENCY", 128),
		Timeout:     time.Duration(envInt("VH_DIAL_TIMEOUT_MS", 700)) * time.Millisecond,
		PluginDir:   env("VH_PLUGIN_DIR", "./plugins"),
		PythonPath:  env("VH_PYTHON_PATH", "python3"),
	}
	if c.DatabaseURL == "" {
		return c, fmt.Errorf("DATABASE_URL is required")
	}
	scope := strings.TrimSpace(os.Getenv("VH_ALLOWED_CIDRS"))
	if scope == "" {
		return c, fmt.Errorf("VH_ALLOWED_CIDRS is required; refusing to start without an explicit authorized scope")
	}
	for _, item := range strings.Split(scope, ",") {
		_, n, err := net.ParseCIDR(strings.TrimSpace(item))
		if err != nil {
			return c, fmt.Errorf("invalid VH_ALLOWED_CIDRS entry %q: %w", item, err)
		}
		c.Allowed = append(c.Allowed, n)
	}
	portText := env("VH_PORTS", "22,23,80,443,445,3306,5432,6379,8080")
	for _, p := range strings.Split(portText, ",") {
		n, err := strconv.Atoi(strings.TrimSpace(p))
		if err != nil || n < 1 || n > 65535 {
			return c, fmt.Errorf("invalid port %q in VH_PORTS", p)
		}
		c.Ports = append(c.Ports, n)
	}
	if c.MaxHosts < 1 || c.MaxHosts > 65536 {
		return c, fmt.Errorf("VH_MAX_HOSTS must be between 1 and 65536")
	}
	if c.Concurrency < 1 || c.Concurrency > 2048 {
		return c, fmt.Errorf("VH_CONCURRENCY must be between 1 and 2048")
	}
	return c, nil
}

func env(k, fallback string) string {
	if v := strings.TrimSpace(os.Getenv(k)); v != "" {
		return v
	}
	return fallback
}
func envInt(k string, fallback int) int {
	v := strings.TrimSpace(os.Getenv(k))
	if v == "" {
		return fallback
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return fallback
	}
	return n
}
