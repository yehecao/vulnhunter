package vuln

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"

	"github.com/example/vulnhunter/internal/model"
)

type CPEMatch struct {
	Severity              string  `json:"severity,omitempty"`
	Score                 float64 `json:"score,omitempty"`
	CVEID                 string  `json:"cve_id"`
	Criteria              string  `json:"criteria"`
	Vendor                string  `json:"vendor"`
	Product               string  `json:"product"`
	VersionStartIncluding string  `json:"version_start_including,omitempty"`
	VersionStartExcluding string  `json:"version_start_excluding,omitempty"`
	VersionEndIncluding   string  `json:"version_end_including,omitempty"`
	VersionEndExcluding   string  `json:"version_end_excluding,omitempty"`
}

type Candidate struct {
	CVEID            string `json:"cve_id"`
	Product          string `json:"product"`
	InstalledVersion string `json:"installed_version"`
	Criteria         string `json:"criteria"`
	MatchStatus      string `json:"match_status"`
	Reason           string `json:"reason"`
}

var versionToken = regexp.MustCompile(`([0-9]+|[A-Za-z]+)`)

// ProductIdentity maps only well-known, confidently fingerprinted products.
// Unknown products intentionally produce no CVE candidates.
func ProductIdentity(s model.Service) (vendor, product string, ok bool) {
	p := strings.ToLower(strings.TrimSpace(s.Product))
	b := strings.ToLower(s.Banner)
	switch p {
	case "nginx":
		return "nginx", "nginx", true
	case "apache", "apache httpd":
		return "apache", "http_server", true
	case "openssh", "ssh":
		if strings.Contains(b, "openssh") {
			return "openbsd", "openssh", true
		}
	}
	if strings.Contains(b, "openssh_") {
		return "openbsd", "openssh", true
	}
	return "", "", false
}

func MatchService(s model.Service, rules []CPEMatch) []Candidate {
	vendor, product, ok := ProductIdentity(s)
	if !ok || strings.TrimSpace(s.Version) == "" {
		return nil
	}
	out := make([]Candidate, 0)
	for _, r := range rules {
		rv, rp := strings.ToLower(r.Vendor), strings.ToLower(r.Product)
		if rv != vendor || rp != product {
			continue
		}
		if versionInRange(s.Version, r) {
			out = append(out, Candidate{CVEID: r.CVEID, Product: s.Product, InstalledVersion: s.Version, Criteria: r.Criteria, MatchStatus: "potential", Reason: "产品与版本范围匹配；尚未进行漏洞利用或补丁状态验证"})
		}
	}
	return out
}

func versionInRange(v string, r CPEMatch) bool {
	if r.VersionStartIncluding != "" && compareVersion(v, r.VersionStartIncluding) < 0 {
		return false
	}
	if r.VersionStartExcluding != "" && compareVersion(v, r.VersionStartExcluding) <= 0 {
		return false
	}
	if r.VersionEndIncluding != "" && compareVersion(v, r.VersionEndIncluding) > 0 {
		return false
	}
	if r.VersionEndExcluding != "" && compareVersion(v, r.VersionEndExcluding) >= 0 {
		return false
	}
	// If no bounds exist, only exact CPE version is safe to match.
	if r.VersionStartIncluding == "" && r.VersionStartExcluding == "" && r.VersionEndIncluding == "" && r.VersionEndExcluding == "" {
		parts := strings.Split(r.Criteria, ":")
		return len(parts) > 5 && parts[5] != "*" && parts[5] != "-" && compareVersion(v, parts[5]) == 0
	}
	return true
}

// compareVersion compares numeric and alphabetic version components without
// floating point conversion (so 1.10 is correctly newer than 1.9).
func compareVersion(a, b string) int {
	at, bt := versionToken.FindAllString(strings.ToLower(a), -1), versionToken.FindAllString(strings.ToLower(b), -1)
	n := len(at)
	if len(bt) > n {
		n = len(bt)
	}
	for i := 0; i < n; i++ {
		x, y := "0", "0"
		if i < len(at) {
			x = at[i]
		}
		if i < len(bt) {
			y = bt[i]
		}
		xn, xe := strconv.ParseUint(x, 10, 64)
		yn, ye := strconv.ParseUint(y, 10, 64)
		cmp := 0
		if xe == nil && ye == nil {
			if xn < yn {
				cmp = -1
			} else if xn > yn {
				cmp = 1
			}
		} else if xe == nil {
			cmp = 1
		} else if ye == nil {
			cmp = -1
		} else {
			cmp = strings.Compare(x, y)
		}
		if cmp != 0 {
			return cmp
		}
	}
	return 0
}

func ParseCPE(criteria string) (vendor, product string, err error) {
	p := strings.Split(criteria, ":")
	if len(p) < 6 || p[0] != "cpe" || p[1] != "2.3" || p[2] != "a" {
		return "", "", fmt.Errorf("unsupported CPE 2.3 criteria %q", criteria)
	}
	return strings.ToLower(p[3]), strings.ToLower(p[4]), nil
}
