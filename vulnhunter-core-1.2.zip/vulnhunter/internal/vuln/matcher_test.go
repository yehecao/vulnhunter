package vuln

import (
	"github.com/example/vulnhunter/internal/model"
	"testing"
)

func TestVersionRangeBoundaries(t *testing.T) {
	r := CPEMatch{VersionStartIncluding: "1.2.0", VersionEndExcluding: "1.4.0"}
	cases := []struct {
		v    string
		want bool
	}{{"1.1.9", false}, {"1.2.0", true}, {"1.3.99", true}, {"1.4.0", false}, {"1.10.0", false}}
	for _, c := range cases {
		if got := versionInRange(c.v, r); got != c.want {
			t.Errorf("versionInRange(%s)=%v want %v", c.v, got, c.want)
		}
	}
}
func TestCompareVersionNumericSegments(t *testing.T) {
	if compareVersion("1.10.0", "1.9.9") <= 0 {
		t.Fatal("1.10.0 must be newer than 1.9.9")
	}
}
func TestMatchRequiresKnownProductAndVersion(t *testing.T) {
	rules := []CPEMatch{{CVEID: "CVE-2024-0001", Vendor: "nginx", Product: "nginx", VersionEndExcluding: "1.25.4"}}
	got := MatchService(model.Service{Product: "nginx", Version: "1.24.0"}, rules)
	if len(got) != 1 || got[0].MatchStatus != "potential" {
		t.Fatalf("unexpected candidates: %#v", got)
	}
	if got := MatchService(model.Service{Product: "unknown", Version: "1.0"}, rules); len(got) != 0 {
		t.Fatal("unknown product must not match")
	}
	if got := MatchService(model.Service{Product: "nginx"}, rules); len(got) != 0 {
		t.Fatal("missing version must not match")
	}
}

func TestParseCPERejectsNonApplicationPart(t *testing.T) {
	if _, _, err := ParseCPE("cpe:2.3:o:linux:linux_kernel:6.1:*:*:*:*:*:*:*"); err == nil {
		t.Fatal("OS CPE must not be accepted by the application-only matcher")
	}
}
