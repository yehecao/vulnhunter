package vuln

import (
	"encoding/json"
	"fmt"
	"io"
	"strings"
	"time"
)

type NVDFeed struct {
	Vulnerabilities []struct {
		CVE NVDEntry `json:"cve"`
	} `json:"vulnerabilities"`
}
type NVDEntry struct {
	ID           string `json:"id"`
	Published    string `json:"published"`
	LastModified string `json:"lastModified"`
	Descriptions []struct {
		Lang  string `json:"lang"`
		Value string `json:"value"`
	} `json:"descriptions"`
	Metrics struct {
		V31 []struct {
			CVSS struct {
				BaseScore float64 `json:"baseScore"`
				Vector    string  `json:"vectorString"`
				Severity  string  `json:"baseSeverity"`
			} `json:"cvssData"`
		} `json:"cvssMetricV31"`
		V30 []struct {
			CVSS struct {
				BaseScore float64 `json:"baseScore"`
				Vector    string  `json:"vectorString"`
				Severity  string  `json:"baseSeverity"`
			} `json:"cvssData"`
		} `json:"cvssMetricV30"`
		V2 []struct {
			CVSS struct {
				BaseScore float64 `json:"baseScore"`
				Vector    string  `json:"vectorString"`
			} `json:"cvssData"`
		} `json:"cvssMetricV2"`
	} `json:"metrics"`
	Configurations []struct {
		Nodes []NVDNode `json:"nodes"`
	} `json:"configurations"`
}
type NVDNode struct {
	CPEMatch []struct {
		Criteria              string `json:"criteria"`
		Vulnerable            bool   `json:"vulnerable"`
		VersionStartIncluding string `json:"versionStartIncluding"`
		VersionStartExcluding string `json:"versionStartExcluding"`
		VersionEndIncluding   string `json:"versionEndIncluding"`
		VersionEndExcluding   string `json:"versionEndExcluding"`
	} `json:"cpeMatch"`
	Children []NVDNode `json:"children"`
}
type CVERecord struct {
	ID, Title, Description, Severity, Vector string
	Score                                    float64
	Published, Modified                      time.Time
	Matches                                  []CPEMatch
}

func DecodeNVD(r io.Reader) ([]CVERecord, error) {
	var feed NVDFeed
	b, err := io.ReadAll(io.LimitReader(r, 1<<30))
	if err != nil {
		return nil, err
	}
	if err = json.Unmarshal(b, &feed); err != nil {
		return nil, fmt.Errorf("decode NVD JSON: %w", err)
	}
	out := make([]CVERecord, 0, len(feed.Vulnerabilities))
	for _, item := range feed.Vulnerabilities {
		c := item.CVE
		rec := CVERecord{ID: c.ID, Published: parseNVDTime(c.Published), Modified: parseNVDTime(c.LastModified)}
		for _, d := range c.Descriptions {
			if d.Lang == "en" {
				rec.Description = d.Value
				break
			}
		}
		if rec.Description == "" && len(c.Descriptions) > 0 {
			rec.Description = c.Descriptions[0].Value
		}
		rec.Title = firstSentence(rec.Description)
		if len(c.Metrics.V31) > 0 {
			x := c.Metrics.V31[0].CVSS
			rec.Score = x.BaseScore
			rec.Vector = x.Vector
			rec.Severity = strings.ToLower(x.Severity)
		} else if len(c.Metrics.V30) > 0 {
			x := c.Metrics.V30[0].CVSS
			rec.Score = x.BaseScore
			rec.Vector = x.Vector
			rec.Severity = strings.ToLower(x.Severity)
		} else if len(c.Metrics.V2) > 0 {
			x := c.Metrics.V2[0].CVSS
			rec.Score = x.BaseScore
			rec.Vector = x.Vector
			rec.Severity = severityFromScore(x.BaseScore)
		}
		for _, cfg := range c.Configurations {
			for _, node := range cfg.Nodes {
				collectMatches(c.ID, node, &rec.Matches)
			}
		}
		if rec.Title == "" {
			rec.Title = c.ID
		}
		out = append(out, rec)
	}
	return out, nil
}
func collectMatches(id string, n NVDNode, out *[]CPEMatch) {
	for _, m := range n.CPEMatch {
		if !m.Vulnerable {
			continue
		}
		vendor, product, err := ParseCPE(m.Criteria)
		if err != nil {
			continue
		}
		*out = append(*out, CPEMatch{CVEID: id, Criteria: m.Criteria, Vendor: vendor, Product: product, VersionStartIncluding: m.VersionStartIncluding, VersionStartExcluding: m.VersionStartExcluding, VersionEndIncluding: m.VersionEndIncluding, VersionEndExcluding: m.VersionEndExcluding})
	}
	for _, child := range n.Children {
		collectMatches(id, child, out)
	}
}
func firstSentence(s string) string {
	s = strings.TrimSpace(s)
	if i := strings.IndexAny(s, ".\n"); i > 0 && i < 240 {
		return s[:i+1]
	}
	if len(s) > 240 {
		return s[:240]
	}
	return s
}
func severityFromScore(v float64) string {
	switch {
	case v >= 9:
		return "critical"
	case v >= 7:
		return "high"
	case v >= 4:
		return "medium"
	case v > 0:
		return "low"
	default:
		return "none"
	}
}

func parseNVDTime(value string) time.Time {
	value = strings.TrimSpace(value)
	for _, layout := range []string{time.RFC3339Nano, "2006-01-02T15:04:05.000", "2006-01-02T15:04:05"} {
		if parsed, err := time.Parse(layout, value); err == nil {
			return parsed.UTC()
		}
	}
	return time.Time{}
}
