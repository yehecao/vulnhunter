package vuln

import (
	"strings"
	"testing"
)

func TestDecodeNVDExtractsCPEApplicability(t *testing.T) {
	raw := `{"vulnerabilities":[{"cve":{"id":"CVE-2024-9999","published":"2024-01-01T00:00:00.000","lastModified":"2024-01-02T00:00:00.000","descriptions":[{"lang":"en","value":"Example vulnerability in nginx."}],"metrics":{"cvssMetricV31":[{"cvssData":{"baseScore":8.1,"vectorString":"CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N","baseSeverity":"HIGH"}}]},"configurations":[{"nodes":[{"cpeMatch":[{"vulnerable":true,"criteria":"cpe:2.3:a:nginx:nginx:*:*:*:*:*:*:*:*","versionEndExcluding":"1.25.4"}]}]}]}}]}`
	records, err := DecodeNVD(strings.NewReader(raw))
	if err != nil {
		t.Fatal(err)
	}
	if len(records) != 1 || records[0].ID != "CVE-2024-9999" {
		t.Fatalf("unexpected records: %#v", records)
	}
	if records[0].Severity != "high" || records[0].Score != 8.1 {
		t.Fatalf("unexpected CVSS: %#v", records[0])
	}
	if len(records[0].Matches) != 1 || records[0].Matches[0].Vendor != "nginx" || records[0].Matches[0].VersionEndExcluding != "1.25.4" {
		t.Fatalf("unexpected CPE matches: %#v", records[0].Matches)
	}
}
