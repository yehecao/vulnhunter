package httpapi

import (
	"context"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/example/vulnhunter/internal/config"
	"github.com/example/vulnhunter/internal/model"
	pluginengine "github.com/example/vulnhunter/internal/plugin"
	"github.com/example/vulnhunter/internal/scanner"
	"github.com/example/vulnhunter/internal/store"
	"github.com/example/vulnhunter/internal/vuln"
)

type Server struct {
	cfg     config.Config
	db      *store.Store
	plugins *pluginengine.Manager
	mu      sync.Mutex
	cancels map[string]context.CancelFunc
}

func New(c config.Config, d *store.Store, plugins *pluginengine.Manager) *Server {
	return &Server{cfg: c, db: d, plugins: plugins, cancels: make(map[string]context.CancelFunc)}
}
func (s *Server) Handler() http.Handler {
	m := http.NewServeMux()
	m.HandleFunc("GET /healthz", func(w http.ResponseWriter, r *http.Request) { write(w, 200, map[string]string{"status": "ok"}) })
	m.HandleFunc("POST /api/v1/scans", s.createScan)
	m.HandleFunc("GET /api/v1/scans", s.listScans)
	m.HandleFunc("GET /api/v1/scans/{id}", s.getScan)
	m.HandleFunc("POST /api/v1/scans/{id}/cancel", s.cancelScan)
	m.HandleFunc("GET /api/v1/assets", s.listAssets)
	m.HandleFunc("GET /api/v1/findings", s.listFindings)
	m.HandleFunc("GET /api/v1/vulnerabilities", s.listVulnerabilities)
	m.HandleFunc("GET /api/v1/plugins", s.listPlugins)
	return securityHeaders(m)
}
func (s *Server) createScan(w http.ResponseWriter, r *http.Request) {
	var req model.ScanRequest
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&req); err != nil {
		writeErr(w, 400, err)
		return
	}
	if len(req.Targets) == 0 {
		writeErr(w, 400, errors.New("targets is required"))
		return
	}
	targets, err := scanner.ParseAndAuthorize(req.Targets, s.cfg.Allowed, s.cfg.MaxHosts)
	if err != nil {
		writeErr(w, 403, err)
		return
	}
	ports := req.Ports
	if len(ports) == 0 {
		ports = s.cfg.Ports
	}
	if len(ports) > 256 {
		writeErr(w, 400, errors.New("maximum 256 ports per task"))
		return
	}
	seen := map[int]bool{}
	for _, p := range ports {
		if p < 1 || p > 65535 {
			writeErr(w, 400, errors.New("ports must be between 1 and 65535"))
			return
		}
		if seen[p] {
			writeErr(w, 400, errors.New("duplicate port"))
			return
		}
		seen[p] = true
	}
	name := strings.TrimSpace(req.Name)
	if name == "" {
		name = "Network inventory"
	}
	t, err := s.db.CreateTask(r.Context(), name, targets, ports)
	if err != nil {
		writeErr(w, 500, err)
		return
	}
	taskCtx, taskCancel := context.WithTimeout(context.Background(), 2*time.Hour)
	s.mu.Lock()
	s.cancels[t.ID] = taskCancel
	s.mu.Unlock()
	go s.runTask(taskCtx, taskCancel, t.ID, targets, ports)
	write(w, http.StatusAccepted, t)
}
func (s *Server) runTask(ctx context.Context, cancel context.CancelFunc, id string, targets []string, ports []int) {
	defer cancel()
	defer func() { s.mu.Lock(); delete(s.cancels, id); s.mu.Unlock() }()
	if err := s.db.SetTaskStatus(ctx, id, "running", ""); err != nil {
		log.Printf("task %s start: %v", id, err)
		return
	}
	engine := scanner.Engine{Timeout: s.cfg.Timeout, Concurrency: s.cfg.Concurrency}
	for _, ip := range targets {
		if ctx.Err() != nil {
			_ = s.db.SetTaskStatus(context.Background(), id, "cancelled", ctx.Err().Error())
			return
		}
		services, err := engine.ScanHost(ctx, ip, ports)
		if err != nil && ctx.Err() != nil {
			_ = s.db.SetTaskStatus(context.Background(), id, "failed", err.Error())
			return
		}
		if len(services) == 0 {
			continue
		}
		assetID, err := s.db.UpsertAsset(ctx, ip)
		if err != nil {
			log.Printf("asset save: %v", err)
			continue
		}
		for _, svc := range services {
			svc.AssetID = assetID
			if err := s.db.UpsertService(ctx, svc); err != nil {
				log.Printf("service save: %v", err)
				continue
			}
			if vendor, product, ok := vuln.ProductIdentity(svc); ok {
				rules, matchErr := s.db.CVEMatches(ctx, vendor, product)
				if matchErr != nil {
					log.Printf("CVE rules lookup: %v", matchErr)
				} else {
					for _, candidate := range vuln.MatchService(svc, rules) {
						if err := s.db.CreateCVEFinding(ctx, id, assetID, candidate, candidateSeverity(rules, candidate.CVEID), candidateScore(rules, candidate.CVEID)); err != nil {
							log.Printf("CVE finding save: %v", err)
						}
					}
				}
			}
			if s.plugins != nil {
				save := func(c context.Context, taskID, assetID, pluginID, title, severity, remediation string, confidence float64, evidence map[string]any) error {
					if evidence == nil {
						evidence = map[string]any{}
					}
					evidence["remediation"] = remediation
					return s.db.CreateFinding(c, taskID, assetID, pluginID, title, severity, remediation, confidence, evidence)
				}
				if err := s.plugins.RunForService(ctx, id, svc, save); err != nil {
					log.Printf("plugin execution task=%s asset=%s port=%d: %v", id, ip, svc.Port, err)
				}
			}
		}
	}
	_ = s.db.SetTaskStatus(context.Background(), id, "completed", "")
}
func (s *Server) listScans(w http.ResponseWriter, r *http.Request) {
	v, e := s.db.ListTasks(r.Context())
	if e != nil {
		writeErr(w, 500, e)
		return
	}
	write(w, 200, v)
}
func (s *Server) getScan(w http.ResponseWriter, r *http.Request) {
	v, e := s.db.GetTask(r.Context(), r.PathValue("id"))
	if e != nil {
		writeErr(w, 404, e)
		return
	}
	write(w, 200, v)
}
func (s *Server) cancelScan(w http.ResponseWriter, r *http.Request) {
	id := r.PathValue("id")
	s.mu.Lock()
	cancel, ok := s.cancels[id]
	s.mu.Unlock()
	if !ok {
		writeErr(w, 409, errors.New("task is not running on this manager instance"))
		return
	}
	cancel()
	write(w, 202, map[string]string{"status": "cancellation_requested", "task_id": id})
}
func (s *Server) listAssets(w http.ResponseWriter, r *http.Request) {
	v, e := s.db.ListAssets(r.Context())
	if e != nil {
		writeErr(w, 500, e)
		return
	}
	write(w, 200, v)
}
func (s *Server) listFindings(w http.ResponseWriter, r *http.Request) {
	v, e := s.db.ListFindings(r.Context())
	if e != nil {
		writeErr(w, 500, e)
		return
	}
	write(w, 200, v)
}
func write(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func writeErr(w http.ResponseWriter, status int, e error) {
	write(w, status, map[string]string{"error": e.Error()})
}
func securityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Cache-Control", "no-store")
		next.ServeHTTP(w, r)
	})
}

func (s *Server) listPlugins(w http.ResponseWriter, r *http.Request) {
	if s.plugins == nil {
		write(w, 200, []any{})
		return
	}
	write(w, 200, s.plugins.List())
}

func candidateSeverity(rules []vuln.CPEMatch, id string) string {
	for _, r := range rules {
		if r.CVEID == id && r.Severity != "" {
			return r.Severity
		}
	}
	return "unknown"
}
func candidateScore(rules []vuln.CPEMatch, id string) float64 {
	for _, r := range rules {
		if r.CVEID == id {
			return r.Score
		}
	}
	return 0
}

func (s *Server) listVulnerabilities(w http.ResponseWriter, r *http.Request) {
	v, e := s.db.ListVulnerabilities(r.Context())
	if e != nil {
		writeErr(w, 500, e)
		return
	}
	write(w, 200, v)
}
