package scanner

import (
	"net"
	"testing"
)

func TestParseAndAuthorize(t *testing.T) {
	_, allowed, _ := net.ParseCIDR("192.168.56.0/24")
	got, err := ParseAndAuthorize([]string{"192.168.56.10", "192.168.56.0/30"}, []*net.IPNet{allowed}, 32)
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 5 {
		t.Fatalf("expected 5 unique IPs, got %d: %v", len(got), got)
	}
}

func TestRejectOutOfScope(t *testing.T) {
	_, allowed, _ := net.ParseCIDR("192.168.56.0/24")
	if _, err := ParseAndAuthorize([]string{"192.168.57.0/24"}, []*net.IPNet{allowed}, 512); err == nil {
		t.Fatal("expected out-of-scope CIDR to be rejected")
	}
}

func TestRejectExpansionLimit(t *testing.T) {
	_, allowed, _ := net.ParseCIDR("10.0.0.0/16")
	if _, err := ParseAndAuthorize([]string{"10.0.0.0/24"}, []*net.IPNet{allowed}, 32); err == nil {
		t.Fatal("expected host expansion limit to be enforced")
	}
}
