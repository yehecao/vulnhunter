package scanner

import (
	"context"
	"fmt"
	"net"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/example/vulnhunter/internal/model"
)

type Engine struct {
	Timeout     time.Duration
	Concurrency int
}

func (e Engine) ScanHost(ctx context.Context, ip string, ports []int) ([]model.Service, error) {
	sem := make(chan struct{}, e.Concurrency)
	var wg sync.WaitGroup
	var mu sync.Mutex
	var found []model.Service
	for _, port := range ports {
		port := port
		wg.Add(1)
		go func() {
			defer wg.Done()
			select {
			case sem <- struct{}{}:
			case <-ctx.Done():
				return
			}
			defer func() { <-sem }()
			d := net.Dialer{Timeout: e.Timeout}
			c, err := d.DialContext(ctx, "tcp", net.JoinHostPort(ip, strconv.Itoa(port)))
			if err != nil {
				return
			}
			defer c.Close()
			_ = c.SetDeadline(time.Now().Add(e.Timeout))
			s := fingerprint(c, port)
			s.IP = ip
			s.Port = port
			s.Protocol = "tcp"
			mu.Lock()
			found = append(found, s)
			mu.Unlock()
		}()
	}
	wg.Wait()
	if ctx.Err() != nil {
		return found, ctx.Err()
	}
	return found, nil
}

func fingerprint(c net.Conn, port int) model.Service {
	v := model.Service{Service: "unknown", Confidence: 0.35}
	if port == 80 || port == 8080 || port == 8000 || port == 8008 || port == 443 || port == 8443 {
		if port == 443 || port == 8443 {
			v.Service = "https"
			v.Confidence = 0.6
			return v
		}
		_, _ = c.Write([]byte("HEAD / HTTP/1.0\r\nHost: scanner.local\r\nConnection: close\r\n\r\n"))
		buf := make([]byte, 2048)
		n, _ := c.Read(buf)
		banner := strings.TrimSpace(string(buf[:n]))
		v.Banner = limit(banner, 1024)
		v.Service = "http"
		v.Confidence = 0.85
		lower := strings.ToLower(banner)
		if strings.Contains(lower, "server: nginx/") {
			v.Product = "nginx"
			v.Version = headerVersion(lower, `server:\s*nginx/([^\s;]+)`)
		}
		if strings.Contains(lower, "server: apache/") {
			v.Product = "apache"
			v.Version = headerVersion(lower, `server:\s*apache/([^\s;]+)`)
		}
		return v
	}
	if port == 22 {
		buf := make([]byte, 256)
		n, _ := c.Read(buf)
		v.Banner = limit(string(buf[:n]), 256)
		v.Service = "ssh"
		v.Confidence = 0.9
		if strings.HasPrefix(v.Banner, "SSH-") {
			if strings.Contains(strings.ToLower(v.Banner), "openssh_") {
				v.Product = "OpenSSH"
				v.Version = headerVersion(strings.ToLower(v.Banner), `openssh_([^\s]+)`)
			} else {
				v.Product = "SSH"
			}
		}
		return v
	}
	switch port {
	case 21:
		v.Service = "ftp"
	case 25, 587:
		v.Service = "smtp"
	case 53:
		v.Service = "dns"
	case 110:
		v.Service = "pop3"
	case 143:
		v.Service = "imap"
	case 445:
		v.Service = "smb"
	case 3306:
		v.Service = "mysql"
	case 5432:
		v.Service = "postgresql"
	case 6379:
		v.Service = "redis"
	case 27017:
		v.Service = "mongodb"
	case 3389:
		v.Service = "rdp"
	default:
		v.Service = fmt.Sprintf("tcp/%d", port)
	}
	return v
}
func limit(s string, n int) string {
	if len(s) > n {
		return s[:n]
	}
	return s
}

func headerVersion(text, pattern string) string {
	re := regexp.MustCompile(pattern)
	m := re.FindStringSubmatch(text)
	if len(m) > 1 {
		return limit(m[1], 128)
	}
	return ""
}
