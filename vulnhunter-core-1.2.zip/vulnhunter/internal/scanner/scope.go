package scanner

import (
	"fmt"
	"net"
)

func ParseAndAuthorize(targets []string, allowed []*net.IPNet, maxHosts int) ([]string, error) {
	seen := map[string]bool{}
	var out []string
	for _, raw := range targets {
		ip := net.ParseIP(raw)
		if ip != nil {
			if !inScope(ip, allowed) {
				return nil, fmt.Errorf("target %s is outside VH_ALLOWED_CIDRS", raw)
			}
			if !seen[ip.String()] {
				seen[ip.String()] = true
				out = append(out, ip.String())
			}
			continue
		}
		_, cidr, err := net.ParseCIDR(raw)
		if err != nil {
			return nil, fmt.Errorf("invalid target %q", raw)
		}
		if !cidrContained(cidr, allowed) {
			return nil, fmt.Errorf("CIDR %s is not wholly contained in an authorized CIDR", raw)
		}
		for ip := cloneIP(cidr.IP); cidr.Contains(ip); inc(ip, cidr.Mask) {
			if len(out) >= maxHosts {
				return nil, fmt.Errorf("target expansion exceeds VH_MAX_HOSTS=%d", maxHosts)
			}
			s := ip.String()
			if !seen[s] {
				seen[s] = true
				out = append(out, s)
			}
		}
	}
	if len(out) == 0 {
		return nil, fmt.Errorf("no targets supplied")
	}
	return out, nil
}
func inScope(ip net.IP, allowed []*net.IPNet) bool {
	for _, n := range allowed {
		if n.Contains(ip) {
			return true
		}
	}
	return false
}
func cidrContained(child *net.IPNet, allowed []*net.IPNet) bool {
	first := cloneIP(child.IP)
	last := cloneIP(child.IP)
	for i := range last {
		last[i] |= ^child.Mask[i]
	}
	for _, p := range allowed {
		if p.Contains(first) && p.Contains(last) {
			return true
		}
	}
	return false
}
func cloneIP(ip net.IP) net.IP { return append(net.IP(nil), ip...) }
func inc(ip net.IP, mask net.IPMask) {
	for i := len(ip) - 1; i >= 0; i-- {
		ip[i]++
		if ip[i] != 0 {
			break
		}
	}
}
