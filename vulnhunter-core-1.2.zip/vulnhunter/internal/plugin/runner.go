package plugin

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"time"
)

type Request struct {
	PluginID string         `json:"plugin_id"`
	Target   map[string]any `json:"target"`
}
type Finding struct {
	PluginID    string         `json:"plugin_id"`
	Title       string         `json:"title"`
	Severity    string         `json:"severity"`
	Confidence  float64        `json:"confidence"`
	Evidence    map[string]any `json:"evidence"`
	Remediation string         `json:"remediation"`
}
type Response struct {
	Status   string    `json:"status"`
	Findings []Finding `json:"findings"`
}

// Run executes a trusted, locally installed plugin script. Production deployments must
// additionally enforce OS-level sandboxing, a fixed interpreter path, filesystem isolation,
// and network egress policy. Never accept arbitrary executable paths from API clients.
func Run(ctx context.Context, pythonPath, scriptPath string, req Request, timeout time.Duration) (Response, error) {
	var result Response
	if timeout <= 0 {
		timeout = 3 * time.Second
	}
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	b, err := json.Marshal(req)
	if err != nil {
		return result, err
	}
	cmd := exec.CommandContext(ctx, pythonPath, scriptPath)
	// Do not leak database credentials or other manager environment variables to plugins.
	cmd.Env = []string{"PATH=" + os.Getenv("PATH"), "LANG=C.UTF-8", "PYTHONIOENCODING=utf-8"}
	cmd.Stdin = bytes.NewReader(b)
	var stdout, stderr limitedBuffer
	stdout.limit = 1 << 20
	stderr.limit = 64 << 10
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	if err := cmd.Run(); err != nil {
		if ctx.Err() != nil {
			return result, fmt.Errorf("plugin timed out or cancelled: %w", ctx.Err())
		}
		return result, fmt.Errorf("plugin process: %w: %s", err, stderr.buf.String())
	}
	if stdout.overflow {
		return result, fmt.Errorf("plugin output exceeds 1 MiB")
	}
	if err := json.Unmarshal(stdout.buf.Bytes(), &result); err != nil {
		return result, fmt.Errorf("invalid plugin JSON: %w", err)
	}
	if result.Status != "completed" {
		return result, fmt.Errorf("plugin returned status %q", result.Status)
	}
	return result, nil
}

// limitedBuffer bounds memory use when a plugin writes excessive output.
type limitedBuffer struct {
	buf      bytes.Buffer
	limit    int
	overflow bool
}

func (b *limitedBuffer) Write(p []byte) (int, error) {
	remaining := b.limit - b.buf.Len()
	if remaining > 0 {
		if len(p) > remaining {
			_, _ = b.buf.Write(p[:remaining])
			b.overflow = true
		} else {
			_, _ = b.buf.Write(p)
		}
	} else if len(p) > 0 {
		b.overflow = true
	}
	return len(p), nil
}
