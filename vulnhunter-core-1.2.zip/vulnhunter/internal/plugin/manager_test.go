package plugin

import (
	"os"
	"path/filepath"
	"testing"
)

func TestDiscoverEnabledPlugin(t *testing.T) {
	root := t.TempDir()
	dir := filepath.Join(root, "sample")
	if err := os.MkdirAll(dir, 0700); err != nil {
		t.Fatal(err)
	}
	manifest := `{"id":"vh.sample-check","name":"Sample","version":"1.0.0","runtime":"python3","entrypoint":"plugin.py","timeout_ms":1000,"enabled":true}`
	if err := os.WriteFile(filepath.Join(dir, "manifest.json"), []byte(manifest), 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, "plugin.py"), []byte("pass\n"), 0600); err != nil {
		t.Fatal(err)
	}
	m, err := Discover(root)
	if err != nil {
		t.Fatal(err)
	}
	if len(m.Plugins) != 1 || m.Plugins[0].Manifest.ID != "vh.sample-check" {
		t.Fatalf("unexpected plugins: %#v", m.Plugins)
	}
}

func TestDiscoverRejectsPathTraversal(t *testing.T) {
	root := t.TempDir()
	dir := filepath.Join(root, "sample")
	if err := os.MkdirAll(dir, 0700); err != nil {
		t.Fatal(err)
	}
	manifest := `{"id":"vh.sample-check","name":"Sample","version":"1.0.0","runtime":"python3","entrypoint":"../escape.py","timeout_ms":1000,"enabled":true}`
	if err := os.WriteFile(filepath.Join(dir, "manifest.json"), []byte(manifest), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := Discover(root); err == nil {
		t.Fatal("expected path traversal rejection")
	}
}
