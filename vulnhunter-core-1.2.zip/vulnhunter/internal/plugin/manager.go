package plugin

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"github.com/example/vulnhunter/internal/model"
)

var idPattern = regexp.MustCompile(`^[a-zA-Z0-9][a-zA-Z0-9._-]{2,127}$`)
var severities = map[string]bool{"info": true, "low": true, "medium": true, "high": true, "critical": true}

type Manifest struct {
	ID          string `json:"id"`
	Name        string `json:"name"`
	Version     string `json:"version"`
	Runtime     string `json:"runtime"`
	Entrypoint  string `json:"entrypoint"`
	TimeoutMS   int    `json:"timeout_ms"`
	Enabled     bool   `json:"enabled"`
	SHA256      string `json:"sha256,omitempty"`
	Description string `json:"description,omitempty"`
}

type Loaded struct {
	Manifest Manifest
	Dir      string
	Script   string
}

type Manager struct {
	PythonPath string
	Root       string
	Plugins    []Loaded
}

func Discover(root string) (*Manager, error) {
	m := &Manager{Root: root, PythonPath: "python3"}
	entries, err := os.ReadDir(root)
	if errors.Is(err, fs.ErrNotExist) {
		return m, nil
	}
	if err != nil {
		return nil, fmt.Errorf("read plugin directory: %w", err)
	}
	seenIDs := make(map[string]bool)
	for _, entry := range entries {
		if !entry.IsDir() || strings.HasPrefix(entry.Name(), ".") {
			continue
		}
		dir := filepath.Join(root, entry.Name())
		manifestPath := filepath.Join(dir, "manifest.json")
		b, err := os.ReadFile(manifestPath)
		if errors.Is(err, fs.ErrNotExist) {
			continue
		}
		if err != nil {
			return nil, fmt.Errorf("read %s: %w", manifestPath, err)
		}
		var mf Manifest
		dec := json.NewDecoder(strings.NewReader(string(b)))
		dec.DisallowUnknownFields()
		if err := dec.Decode(&mf); err != nil {
			return nil, fmt.Errorf("decode %s: %w", manifestPath, err)
		}
		if err := validateManifest(mf); err != nil {
			return nil, fmt.Errorf("plugin %s: %w", entry.Name(), err)
		}
		if seenIDs[mf.ID] {
			return nil, fmt.Errorf("duplicate plugin id %q", mf.ID)
		}
		seenIDs[mf.ID] = true
		if !mf.Enabled {
			continue
		}
		clean := filepath.Clean(mf.Entrypoint)
		if filepath.IsAbs(clean) || clean == "." || clean == ".." || strings.HasPrefix(clean, ".."+string(filepath.Separator)) {
			return nil, fmt.Errorf("plugin %s: entrypoint must stay inside plugin directory", mf.ID)
		}
		script := filepath.Join(dir, clean)
		resolvedDir, err := filepath.EvalSymlinks(dir)
		if err != nil {
			return nil, err
		}
		resolvedScript, err := filepath.EvalSymlinks(script)
		if err != nil {
			return nil, fmt.Errorf("plugin %s: resolve entrypoint: %w", mf.ID, err)
		}
		rel, err := filepath.Rel(resolvedDir, resolvedScript)
		if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
			return nil, fmt.Errorf("plugin %s: entrypoint symlink escapes plugin directory", mf.ID)
		}
		script = resolvedScript
		st, err := os.Stat(script)
		if err != nil || !st.Mode().IsRegular() {
			return nil, fmt.Errorf("plugin %s: entrypoint is not a regular file", mf.ID)
		}
		if mf.SHA256 != "" {
			data, err := os.ReadFile(script)
			if err != nil {
				return nil, err
			}
			sum := sha256.Sum256(data)
			if !strings.EqualFold(mf.SHA256, hex.EncodeToString(sum[:])) {
				return nil, fmt.Errorf("plugin %s: SHA-256 mismatch", mf.ID)
			}
		}
		m.Plugins = append(m.Plugins, Loaded{Manifest: mf, Dir: dir, Script: script})
	}
	return m, nil
}

func validateManifest(m Manifest) error {
	if !idPattern.MatchString(m.ID) {
		return errors.New("invalid id")
	}
	if strings.TrimSpace(m.Name) == "" || strings.TrimSpace(m.Version) == "" {
		return errors.New("name and version are required")
	}
	if m.Runtime != "python3" {
		return errors.New("runtime must be python3")
	}
	if m.Entrypoint == "" || filepath.Ext(m.Entrypoint) != ".py" {
		return errors.New("entrypoint must be a .py file")
	}
	if m.TimeoutMS < 100 || m.TimeoutMS > 30000 {
		return errors.New("timeout_ms must be between 100 and 30000")
	}
	if m.SHA256 != "" {
		if len(m.SHA256) != 64 {
			return errors.New("sha256 must be a 64-character hex digest")
		}
		if _, err := hex.DecodeString(m.SHA256); err != nil {
			return errors.New("sha256 must be hexadecimal")
		}
	}
	return nil
}

func (m *Manager) RunForService(ctx context.Context, taskID string, svc model.Service, save func(context.Context, string, string, string, string, string, string, float64, map[string]any) error) error {
	for _, p := range m.Plugins {
		request := Request{PluginID: p.Manifest.ID, Target: map[string]any{
			"ip": svc.IP, "port": svc.Port, "protocol": svc.Protocol,
			"service": svc.Service, "product": svc.Product, "version": svc.Version,
			"banner": svc.Banner, "confidence": svc.Confidence,
		}}
		response, err := Run(ctx, m.PythonPath, p.Script, request, time.Duration(p.Manifest.TimeoutMS)*time.Millisecond)
		if err != nil {
			return fmt.Errorf("plugin %s: %w", p.Manifest.ID, err)
		}
		if len(response.Findings) > 100 {
			return fmt.Errorf("plugin %s returned too many findings", p.Manifest.ID)
		}
		for _, f := range response.Findings {
			if f.PluginID != p.Manifest.ID {
				return fmt.Errorf("plugin %s returned mismatched plugin_id", p.Manifest.ID)
			}
			if strings.TrimSpace(f.Title) == "" || !severities[strings.ToLower(f.Severity)] || f.Confidence < 0 || f.Confidence > 1 {
				return fmt.Errorf("plugin %s returned invalid finding", p.Manifest.ID)
			}
			if err := save(ctx, taskID, svc.AssetID, p.Manifest.ID, f.Title, strings.ToLower(f.Severity), f.Remediation, f.Confidence, f.Evidence); err != nil {
				return err
			}
		}
	}
	return nil
}

// List returns public plugin metadata without exposing local filesystem paths.
func (m *Manager) List() []Manifest {
	out := make([]Manifest, 0, len(m.Plugins))
	for _, p := range m.Plugins {
		out = append(out, p.Manifest)
	}
	return out
}
