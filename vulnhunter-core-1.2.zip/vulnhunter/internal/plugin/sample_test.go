package plugin

import (
	"path/filepath"
	"testing"
)

func TestRepositorySamplePluginManifest(t *testing.T) {
	root := filepath.Join("..", "..", "plugins")
	m, err := Discover(root)
	if err != nil {
		t.Fatal(err)
	}
	if len(m.Plugins) != 1 {
		t.Fatalf("expected one sample plugin, got %d", len(m.Plugins))
	}
	if m.Plugins[0].Manifest.ID != "vh.telnet-policy" {
		t.Fatalf("unexpected plugin id %q", m.Plugins[0].Manifest.ID)
	}
}
