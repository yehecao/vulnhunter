// vulnhunter-import-nvd imports a downloaded NVD CVE API 2.0 JSON response.
// It does not fetch data itself; download feeds through an approved network path.
package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"os"

	"github.com/example/vulnhunter/internal/store"
	"github.com/example/vulnhunter/internal/vuln"
)

func main() {
	file := flag.String("file", "", "path to NVD API 2.0 JSON file")
	flag.Parse()
	if *file == "" {
		log.Fatal("usage: vulnhunter-import-nvd -file nvdcve-2.0.json")
	}
	dsn := os.Getenv("DATABASE_URL")
	if dsn == "" {
		log.Fatal("DATABASE_URL is required")
	}
	f, err := os.Open(*file)
	if err != nil {
		log.Fatal(err)
	}
	defer f.Close()
	records, err := vuln.DecodeNVD(f)
	if err != nil {
		log.Fatal(err)
	}
	db, err := store.Open(context.Background(), dsn)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()
	for i, rec := range records {
		if err := db.ImportVulnerability(context.Background(), rec); err != nil {
			log.Fatalf("import %s: %v", rec.ID, err)
		}
		if (i+1)%500 == 0 {
			fmt.Printf("imported %d/%d CVEs\n", i+1, len(records))
		}
	}
	fmt.Printf("imported %d CVE records\n", len(records))
}
