#!/usr/bin/env python3
"""Metadata-only policy check. No network access or exploitation is performed."""
import json
import sys

request = json.load(sys.stdin)
target = request.get("target", {})
findings = []
if str(target.get("service", "")).lower() == "telnet" or target.get("port") == 23:
    findings.append({
        "plugin_id": request["plugin_id"],
        "title": "Telnet service exposed",
        "severity": "medium",
        "confidence": 0.98,
        "evidence": {
            "ip": target.get("ip"),
            "port": target.get("port"),
            "service": target.get("service"),
            "banner": target.get("banner", "")[:256]
        },
        "remediation": "Disable Telnet and use SSH or another encrypted management protocol."
    })
json.dump({"status": "completed", "findings": findings}, sys.stdout)
sys.stdout.write("\n")
