-- VulnHunter 1.2: normalized CPE applicability records imported from NVD feeds.
CREATE TABLE IF NOT EXISTS cve_cpe_matches (
    id BIGSERIAL PRIMARY KEY,
    cve_id VARCHAR(32) NOT NULL REFERENCES vulnerabilities(cve_id) ON DELETE CASCADE,
    criteria TEXT NOT NULL,
    vendor VARCHAR(128) NOT NULL,
    product VARCHAR(128) NOT NULL,
    version_start_including VARCHAR(128),
    version_start_excluding VARCHAR(128),
    version_end_including VARCHAR(128),
    version_end_excluding VARCHAR(128),
    vulnerable BOOLEAN NOT NULL DEFAULT true
);
CREATE INDEX IF NOT EXISTS idx_cve_cpe_product ON cve_cpe_matches(vendor, product);
CREATE UNIQUE INDEX IF NOT EXISTS uq_cve_cpe_range ON cve_cpe_matches(cve_id, criteria, COALESCE(version_start_including, ''), COALESCE(version_start_excluding, ''), COALESCE(version_end_including, ''), COALESCE(version_end_excluding, ''));
ALTER TABLE scan_findings ADD COLUMN IF NOT EXISTS cve_id VARCHAR(32);
ALTER TABLE scan_findings ADD COLUMN IF NOT EXISTS match_status VARCHAR(32) NOT NULL DEFAULT 'observed';
CREATE INDEX IF NOT EXISTS idx_findings_cve ON scan_findings(cve_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_findings_task_asset_cve
    ON scan_findings(task_id, asset_id, cve_id) WHERE cve_id IS NOT NULL;
