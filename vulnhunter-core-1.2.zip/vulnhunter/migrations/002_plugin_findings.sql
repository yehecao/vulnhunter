-- VulnHunter 1.1: retain remediation guidance returned by trusted plugins.
ALTER TABLE scan_findings
    ADD COLUMN IF NOT EXISTS remediation TEXT NOT NULL DEFAULT '';
