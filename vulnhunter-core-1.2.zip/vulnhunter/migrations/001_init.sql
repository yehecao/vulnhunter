CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS assets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ip_address INET NOT NULL UNIQUE,
    hostname VARCHAR(255),
    os_name VARCHAR(128),
    os_version VARCHAR(128),
    asset_type VARCHAR(64),
    mac_address MACADDR,
    first_seen TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_assets_last_seen ON assets(last_seen DESC);

CREATE TABLE IF NOT EXISTS scan_tasks (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    status VARCHAR(32) NOT NULL,
    target_scope TEXT[] NOT NULL,
    ports INTEGER[] NOT NULL,
    error_text TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    started_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_scan_tasks_created ON scan_tasks(created_at DESC);

CREATE TABLE IF NOT EXISTS asset_services (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    asset_id UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
    port INTEGER NOT NULL CHECK (port BETWEEN 1 AND 65535),
    protocol VARCHAR(8) NOT NULL,
    service_name VARCHAR(128) NOT NULL,
    product VARCHAR(128),
    version VARCHAR(128),
    banner TEXT,
    confidence NUMERIC(4,3) NOT NULL DEFAULT 0.5,
    first_seen TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_seen TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(asset_id, port, protocol)
);
CREATE INDEX IF NOT EXISTS idx_services_asset ON asset_services(asset_id);

CREATE TABLE IF NOT EXISTS scan_findings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id UUID NOT NULL REFERENCES scan_tasks(id) ON DELETE CASCADE,
    asset_id UUID NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
    plugin_id VARCHAR(128) NOT NULL,
    title VARCHAR(512) NOT NULL,
    severity VARCHAR(32) NOT NULL,
    confidence NUMERIC(4,3) NOT NULL,
    evidence JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_findings_task ON scan_findings(task_id);
CREATE INDEX IF NOT EXISTS idx_findings_asset ON scan_findings(asset_id);
CREATE INDEX IF NOT EXISTS idx_findings_created ON scan_findings(created_at DESC);

CREATE TABLE IF NOT EXISTS vulnerabilities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cve_id VARCHAR(32) UNIQUE,
    title VARCHAR(512) NOT NULL,
    description TEXT,
    cvss_score NUMERIC(3,1),
    cvss_vector VARCHAR(255),
    epss_score NUMERIC(8,7),
    severity VARCHAR(32),
    cisa_kev BOOLEAN NOT NULL DEFAULT false,
    published_at TIMESTAMPTZ,
    modified_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS plugin_registry (
    id VARCHAR(128) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    version VARCHAR(64) NOT NULL,
    runtime VARCHAR(32) NOT NULL,
    checksum_sha256 CHAR(64),
    enabled BOOLEAN NOT NULL DEFAULT false,
    manifest JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    actor VARCHAR(255) NOT NULL DEFAULT 'system',
    action VARCHAR(128) NOT NULL,
    target VARCHAR(512),
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
